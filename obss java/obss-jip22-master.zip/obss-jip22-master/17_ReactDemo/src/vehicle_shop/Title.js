export default (props) => {
    return (
        <div>
            <p className="title">{props.title}</p>
            <p>{props.subTitle}</p>
        </div>
    );
};
