import ReactDOM from "react-dom";
import ButtonClass from "./ButtonClass";

export default () => {
    const root = document.getElementById("root");

    ReactDOM.render(<ButtonClass />, root);
};
