import ReactDOM from "react-dom";
import Switch from "./switchFunc";

export default () => {
    const root = document.getElementById("root");

    ReactDOM.render(<Switch />, root);
};
