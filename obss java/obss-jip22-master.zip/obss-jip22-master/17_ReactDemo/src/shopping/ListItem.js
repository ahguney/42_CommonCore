export default (props) => {
    return <li>{props.item}</li>;
};
