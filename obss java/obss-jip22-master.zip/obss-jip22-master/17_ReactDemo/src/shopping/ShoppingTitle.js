export default (props) => {
    return (
        <div>
            <h1>{props.title}</h1>
            <h5>Total number of items: {props.itemNum}</h5>
        </div>
    );
};
