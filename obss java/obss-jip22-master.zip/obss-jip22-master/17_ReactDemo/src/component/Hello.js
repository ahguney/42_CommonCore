import { render } from "react";

function Hello({ name }) {
    return <h1>Hello there {name}</h1>;
}

export default Hello