package tr.com.obss.jip.bookportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookPortal {

    public static void main(String[] args) {
        SpringApplication.run(BookPortal.class, args);
    }
}
