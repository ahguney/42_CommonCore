package tr.com.obss.jip.bookportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookPortalTests {

    @Test
    void contextLoads() {}
}
