package tr.com.obss.javaignite.busreservation;

public enum Destination {
    ISTANBUL,
    ANKARA,
    ADANA
}
