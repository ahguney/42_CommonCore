import { Typography } from "antd";
const { Title } = Typography;

const About = () => {
  return (
    <div>
      <Title>About</Title>
      <p>
        This site was pretty hard to make, so the developer hopes you like it.
      </p>
    </div>
  );
};

export default About;
