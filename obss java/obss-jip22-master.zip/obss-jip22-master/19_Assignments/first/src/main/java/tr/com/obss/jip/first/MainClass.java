package tr.com.obss.jip.first;

public class MainClass {
    public static void main(String[] args) {
        Class3.methodOne();
    }
}
