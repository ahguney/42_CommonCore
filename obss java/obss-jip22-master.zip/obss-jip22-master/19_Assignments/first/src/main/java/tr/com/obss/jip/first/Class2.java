package tr.com.obss.jip.first;

public class Class2 {

    public static void methodTwo() throws Exception {
        Class1.methodThree();
    }
}
