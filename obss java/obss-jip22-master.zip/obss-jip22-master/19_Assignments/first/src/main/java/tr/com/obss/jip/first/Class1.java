package tr.com.obss.jip.first;

public class Class1 {

    public static void methodThree() throws Exception {
        throw new Exception("Random exception");
    }
}
