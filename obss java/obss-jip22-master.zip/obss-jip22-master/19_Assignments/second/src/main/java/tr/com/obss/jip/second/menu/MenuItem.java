package tr.com.obss.jip.second.menu;

public interface MenuItem {
    void prepare();

    void cook();

    void send();
}
