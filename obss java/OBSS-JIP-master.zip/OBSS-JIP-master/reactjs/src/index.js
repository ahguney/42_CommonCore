// import { renderApp, renderApp1 } from "./App";
// import simpleCounterRenderer from "./first-day/counter";
// import helloFrom from "./first-day/hello-from";
// import styleUsage from "./first-day/style-usage";
// import nestedElement from "./first-day/nested-element";
// import productExample from "./first-day/product-example";
// import conditionalRendering from "./first-day/conditional-rendering";
// import shoppingApp from "./first-day/shopping-app";
// import helloClass from "./second-day/hello-react";
// import shoppingApp from "./second-day/shopping-app";
// import fooBar from "./second-day/state-example";
// import counter from "./second-day/state-example/";
// import counter from "./second-day/lifecycle-counter";
// import carList from "./second-day/lifecycle-methods";
// import  switch2 from "./second-day/event-handlers";
// import productList from "./second-day/listing-elements";
import renderRoutingExample from "./second-day/routing-example"


renderRoutingExample();
// productList();
// switch2();
// carList();
// counter();
// counter();
// fooBar();
// shoppingApp();
// helloClass();
// shoppingApp();
// conditionalRendering();
// productExample();
// nestedElement();
// styleUsage();
// helloFrom();
// simpleCounterRenderer();
// renderApp();