export default function Hello2() {
  return <h1>Hello REACT2</h1>;
}