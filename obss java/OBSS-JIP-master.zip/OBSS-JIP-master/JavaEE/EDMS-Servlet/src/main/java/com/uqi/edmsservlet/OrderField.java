package com.uqi.edmsservlet;

public enum OrderField {
    name, surname, birth_year
}