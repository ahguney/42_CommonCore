package EDMS;

public enum OrderField {
    name, surname, birth_year
}
