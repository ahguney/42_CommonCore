package EDMS;

public record Employee(int id, String name, String surname, String title, int birthYear) {
}
