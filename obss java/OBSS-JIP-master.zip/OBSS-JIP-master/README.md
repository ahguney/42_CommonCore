# OBSS-JIP
This repository includes the projects done during the OBSS-2022 Java Ignite Program summer internship. For proper installation, it is recommended to open the repo with IntelliJ IDEA after cloning. (Moduling and configurations in the project files are ready for the project modules to be built.)

## PROJECT CI STATUS
[![Java CI with Maven](https://github.com/ugurcanerdogan/OBSS-JIP/actions/workflows/maven.yml/badge.svg)](https://github.com/ugurcanerdogan/OBSS-JIP/actions/workflows/maven.yml)
[![CodeQL](https://github.com/ugurcanerdogan/OBSS-JIP/actions/workflows/codeql.yml/badge.svg)](https://github.com/ugurcanerdogan/OBSS-JIP/actions/workflows/codeql.yml)
