import Item from "./Item"

export default function Items() {

    return (
        <>
            <div id="items">


                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>

                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>

                <Item/>
                <Item/>
                <Item/>

            </div>
        </>
    )
}