package com.enesergen.bookPortal.core.utilities.configurations.secuirties;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;


public class MyPasswordEncoder extends BCryptPasswordEncoder {
}
