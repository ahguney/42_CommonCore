package com.enesergen.bookPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
