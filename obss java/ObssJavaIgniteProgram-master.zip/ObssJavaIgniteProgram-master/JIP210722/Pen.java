public class Pen {



    public void draw(Shape shape) {
        shape.draw();
    }

    public void changeColor(Shape shape,String color) {
        shape.changeColor(color);
    }


}
