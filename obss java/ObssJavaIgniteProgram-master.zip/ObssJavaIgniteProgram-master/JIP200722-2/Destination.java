public enum Destination {
    ISTANBUL,ANKARA,MALATYA
}
