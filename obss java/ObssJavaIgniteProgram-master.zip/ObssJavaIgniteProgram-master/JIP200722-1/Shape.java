abstract class Shape {
    String color;
    abstract double calculateArea();
    abstract void setColor(String color);
    abstract String getColor();
}
