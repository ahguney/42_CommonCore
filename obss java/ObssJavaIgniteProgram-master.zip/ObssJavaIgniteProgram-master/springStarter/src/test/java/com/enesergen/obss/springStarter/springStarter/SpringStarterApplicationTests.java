package com.enesergen.obss.springStarter.springStarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
