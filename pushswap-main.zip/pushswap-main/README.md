# PUSHSWAP

Bu proje size mümkün olan en düşük sayıda hamleyi yaparak ve sınırlı bir talimat seti kullanarak bir yığındaki verileri sıralatacak. Başarabilmek için çeşitli tiplerdeki algoritmaları manipüle edip optimal bir veri sıralaması için en uygun olanını(birçoğu arasından) seçmeniz gerekecek.