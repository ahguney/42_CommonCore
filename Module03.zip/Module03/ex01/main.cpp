#include "ScavTrap.hpp"

int main()
{
	std::cout << std::endl;
	ScavTrap Default;
	ScavTrap s1("no1");
	ScavTrap s2("no2");

	std::cout << std::endl;
	s1.attack("no2");
	std::cout << std::endl;
	s2.takeDamage(s1.get_damage());
	std::cout << std::endl;
	s2.beRepaired(10);

	std::cout << std::endl;
	s2.guardGate();

	std::cout << std::endl;
	Default.attack("no2");
	std::cout << std::endl;
	s2.takeDamage(Default.get_damage());
	std::cout << std::endl;
	return 0;
}