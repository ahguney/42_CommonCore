#include "ScavTrap.hpp"
#include "FragTrap.hpp"
#include "DiamondTrap.hpp"

int main(void)
{
	{
		std::cout << std::endl;
		DiamondTrap d1("D1");
		std::cout << std::endl;
		DiamondTrap d2("D2");
		std::cout << std::endl;
		DiamondTrap d3;

		std::cout << std::endl;
		d1.whoAmI();

		std::cout << std::endl;
		d2.guardGate();

		std::cout << std::endl;
		d3.highFivesGuys();

		std::cout << std::endl;
		d1.attack("Diamond2");

		std::cout << std::endl;
		d2.takeDamage(d1.get_damage());

		std::cout << std::endl;
		d2.attack("Diamond3");

		std::cout << std::endl;
		d3.takeDamage(d2.get_damage());
		std::cout << std::endl;
	}
	return 0;
}