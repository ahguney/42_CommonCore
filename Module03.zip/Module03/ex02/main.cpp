#include "ScavTrap.hpp"
#include "FragTrap.hpp"

int main(void)
{
	std::cout << std::endl;
	ClapTrap Default;
	ScavTrap s1("no1");
	FragTrap f1("fr1");

	std::cout << std::endl;
	s1.attack("Fr1");
	
	std::cout << std::endl;
	f1.takeDamage(s1.get_damage());

	std::cout << std::endl;
	s1.guardGate();

	std::cout << std::endl;
	f1.attack("no1");

	std::cout << std::endl;
	s1.takeDamage(f1.get_damage());

	std::cout << std::endl;
	Default.beRepaired(90);

	std::cout << std::endl;
	f1.highFivesGuys();
	std::cout << std::endl;
	return 0;
}