#ifndef ROBOTOMYREQUESTFORM_H
# define ROBOTOMYREQUESTFORM_H

# include <iostream>
# include <cstdlib>
# include <ctime>
# include "AForm.hpp"

class RobotomyRequestForm: public AForm {
	
public:
		RobotomyRequestForm();
        RobotomyRequestForm(const RobotomyRequestForm&);
		RobotomyRequestForm(const std::string target);
        virtual ~RobotomyRequestForm();
        RobotomyRequestForm &operator=(const RobotomyRequestForm&);

		virtual void execute(Bureaucrat const & executor) const;

};

#endif
