#include "Cat.hpp"
#include "Dog.hpp"
#include "WrongCat.hpp"

int main(void)
{
	//Animal	*cat1 = new Animal();
	Cat		*cat1 = new Cat();
	
	std::cout << std::endl;
	cat1->makeSound();
	std::cout << std::endl;

	delete cat1;
	return 0;
}

