#include "../includes/minishell.h"

void	ft_clear_fd(void)
{
	int	i;

	i = 3;
	while (i < 101)
	{
		close(i);
		i++;
	}
}
