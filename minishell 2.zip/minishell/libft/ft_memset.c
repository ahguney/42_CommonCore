#include "../includes/minishell.h"

void	*ft_memset(void *str, int nbr, size_t len)
{
	while (len-- > 0)
		((unsigned char *)str)[len] = (unsigned char)nbr;
	return (str);
}
