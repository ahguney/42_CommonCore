#include "../includes/minishell.h"

bool	ft_is_only(char *buffer, char c)
{
	int	i;

	i = 0;
	if (!buffer)
		return (false);
	while (buffer[i] != '\0')
	{
		if (buffer[i] != c)
			return (false);
		i++;
	}
	return (true);
}
