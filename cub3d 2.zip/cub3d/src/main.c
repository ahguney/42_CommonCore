/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcil <fcil@student.42.fr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/10 20:50:50 by fcil              #+#    #+#             */
/*   Updated: 2022/10/14 13:40:52 by fcil             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

static int	ft_cubed(t_all *data, char *strmap)
{
	data->mlx = mlx_init();
	ft_parse(data, strmap);
	data->win.ptr = mlx_new_window(data->mlx,
			data->win.x, data->win.y, "cub3D");
	ft_init_ray(data);
	mlx_hook(data->win.ptr, 2, 0, &ft_key_hold, data);
	mlx_hook(data->win.ptr, 3, 1, ft_key_release, data);
	mlx_hook(data->win.ptr, 17, 0, &ft_close, data);
	//ft_logic(data);          
	mlx_loop_hook(data->mlx, ft_logic, data);
	mlx_loop(data->mlx);
	return (1);
}

static void	ft_init2(t_all *data, char *strmap)
{
	t_map	map;
	t_tex	tex;
	t_stk	*stk;

	map.tab = NULL;
	tex.n = NULL;
	tex.s = NULL;
	tex.e = NULL;
	tex.w = NULL;
	stk = NULL;
	map.x = 0;
	map.y = 0;
	tex.c = NONE;
	tex.f = NONE;
	data->map = map;
	data->tex = tex;
	data->stk = stk;
	data->key_control = 0;
	ft_cubed(data, strmap);
}

static void	ft_init(char *strmap)
{
	t_all		data;
	t_win		win;
	t_img		img;
	t_dir		dir;

	win.ptr = NULL;
	img.ptr = NULL;
	img.adr = NULL;
	win.x = SIZE_X;
	win.y = SIZE_Y;
	win.m = INT_MAX;
	dir.x = 0;
	dir.y = 0;
	data.mlx = NULL;
	data.pos_x = 0;
	data.pos_y = 0;
	data.win = win;
	data.img = img;
	data.dir = dir;
	ft_init2(&data, strmap);
}

int	main(int ac, char **av)
{
	if (ac == 2 && ft_extcheck(av[1], ".cub"))
		ft_init(av[1]);
	else
		error("Error : Invalid arguments");
	return (0);
}
