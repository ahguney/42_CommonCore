/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ahguney <ahguney@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/25 18:12:55 by ahguney           #+#    #+#             */
/*   Updated: 2023/09/25 18:12:55 by ahguney          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "PmergeMe.hpp"

int main(int argc, char **argv)
{
    if (argc < 2) 
	{
        std::cerr << "Error: Wrong arguments" << std::endl;
        return 1;
    }
	std::vector<int> input;
    for (int i = 1; i < argc; i++)
	{
        int num = std::atoi(argv[i]);
		if (num < 0)
		{
			std::cerr << "Error: Integers must be positive" << std::endl;
			return (1);
		}
		else if (num == 0 && *argv[i] != '0')
		{
			std::cerr << "Error: only integers" << std::endl;
			return (1);
		}
        input.push_back(num);
    }
	try
	{
		Pmerge sorter(input);
		sorter.result();
	}
	catch (const std::exception& ex)
	{
		std::cout << ex.what() << std::endl;
	}
    return 0;
}