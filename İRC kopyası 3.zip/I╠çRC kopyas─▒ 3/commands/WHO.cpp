#include "../Server.hpp"

void Server::who(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() != 2)
		return (sendMessageToClient(fd, "You must pass 1 argument"));
	if (clients[fd]->isRegistered() == false)
		return (sendMessageToClient(fd, "You must register first"));
	if (channels.find(tokens[1]) == channels.end())
		return (sendMessageToClient(fd, "There is not a channel with that name"));
	if (channels[tokens[1]]->checkUser(clients[fd]->getNickname()) == false)
		return (sendMessageToClient(fd, "You are not member of the channel"));
	
	sendMessageToClient(fd, "The channel has " + std::to_string(channels[tokens[1]]->getUserCount()) + " member");
	std::map<std::string, int> users = channels[tokens[1]]->getUsers();
	std::map<std::string, int>::iterator it;
	for (it = users.begin(); it != users.end(); it++)
	{
		if (it->first == channels[tokens[1]]->getOperator())
			sendMessageToClient(fd, it->first + " - ADMIN");
		else
			sendMessageToClient(fd, it->first);
	}
}