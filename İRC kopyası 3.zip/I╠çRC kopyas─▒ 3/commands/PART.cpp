#include "../Server.hpp"

void Server::part(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() < 2)
		return (sendMessageToClient(fd, "You must pass 1 argument at least"));

	std::map<std::string, Channel *>::iterator it = channels.find(tokens[1]);
	if (it == channels.end())
		return (sendMessageToClient(fd, "There is not a channel with that name"));

	if (it->second->kickUser(clients[fd]->getNickname(), tokens) == false)
		return (sendMessageToClient(fd, "You are not member of the channel"));

	std::string str = ":" + clients[fd]->getNickname() + " PART :" + tokens[1];

	send(clients[fd]->getFD(), str.c_str(),str.size(),0);
	
	clients[fd]->eraseChannel(it->first);
	
	std::string channelName = it->second->getChannelName();

	if (channels[it->second->getChannelName()]->getUserCount() == 0)
	{
		delete it->second;
		channels.erase(channelName);
	}
	else if (it->second->getOperator() == clients[fd]->getNickname())
	{
		int newOperatorFD = it->second->getUsers().begin()->second;
		it->second->setOperator(clients[newOperatorFD]->getNickname());
		sendMessageToClient(newOperatorFD, "You have been appointed as a new operator on " + it->second->getChannelName());
	}
}