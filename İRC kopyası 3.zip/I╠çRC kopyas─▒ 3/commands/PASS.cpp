#include "../Server.hpp"

void Server::pass(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() != 2)
		return(sendMessageToClient(fd, "You must pass 1 argument"));
	if (tokens[1] != password)
		return(sendMessageToClient(fd, "Password incorrect"));
	clients[fd]->setEnteredPass();
	sendMessageToClient(fd, "Password accepted");
}