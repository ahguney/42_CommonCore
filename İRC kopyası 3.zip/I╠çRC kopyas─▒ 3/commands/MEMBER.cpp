#include "../Server.hpp"

void Server::member(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() != 1)
		return (sendMessageToClient(fd, "You can't pass argument"));
	if (clients[fd]->isRegistered() == false)
		return (sendMessageToClient(fd, "You must register first"));

	std::vector<std::string> userChannels = clients[fd]->getChannels();
	for (size_t i = 0; i < userChannels.size(); i++)
	{
		if (channels[userChannels[i]]->getOperator() == clients[fd]->getNickname())
			sendMessageToClient(fd, userChannels[i] + " - ADMIN");
		else
			sendMessageToClient(fd, userChannels[i]);
	}
}