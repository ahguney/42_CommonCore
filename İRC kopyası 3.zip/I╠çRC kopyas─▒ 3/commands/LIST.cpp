#include "../Server.hpp"

void Server::list(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() != 1)
		return (sendMessageToClient(fd, "You can't pass argument"));
	if (clients[fd]->isRegistered() == false)
		return (sendMessageToClient(fd, "You must register first"));
	
	std::map<std::string, Channel *>::iterator it;
	for (it = channels.begin(); it != channels.end(); it++)
	{
		if (it->second->getOperator() == clients[fd]->getNickname())
			sendMessageToClient(fd, it->second->getChannelName() + " - ADMIN");
		else if (it->second->checkUser(clients[fd]->getNickname()))
			sendMessageToClient(fd, it->second->getChannelName() + " - MEMBER");
		else
			sendMessageToClient(fd, it->second->getChannelName());
	}
}