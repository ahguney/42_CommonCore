#include "../Server.hpp"

void Server::privmsg(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() < 3)
		return (sendMessageToClient(fd, "You must pass 2 argument at least"));
	if (clients[fd]->isRegistered() == false)
		return (sendMessageToClient(fd, "You must register first"));

	std::string targetName = tokens[1];
	if (targetName[0] == '#') // CHANNEL
	{
		std::map<std::string, Channel *>::iterator it;
		it = channels.find(targetName);
		if (it == channels.end())
			return (sendMessageToClient(fd, "There is not a channel with that name"));
		if (channels[tokens[1]]->checkUser(clients[fd]->getNickname()) == false)
		{
			std::cout << "-------------"<< clients[fd]->getNickname() << clients.size() << "------------"<< std::endl;
			return (sendMessageToClient(fd, "You are not member of the channel"));	
		}
		it->second->showMessage(clients[fd]->getNickname(), getMessage(tokens));
	}
	else // USER
	{
		int recieverFD = -1;
		std::map<int, Client *>::iterator it;
		for (it = clients.begin(); it != clients.end(); ++it)
		{
			if (it->second->getNickname() != targetName)
				continue;
			recieverFD = it->second->getFD();
		}
		if (recieverFD == -1)
			return (sendMessageToClient(fd, "There is not an user with that name"));

		std::string message = getMessage(tokens);
		message = ":" + clients[fd]->getNickname() + " PRIVMSG " + tokens[1] + " :" + message;
		send(recieverFD, message.c_str(), message.size(), 0);
	}
}