#include "../Server.hpp"

void Server::join(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() != 2)
		return (sendMessageToClient(fd, "You must pass 1 argument"));
	if (clients[fd]->isRegistered() == false)
		return (sendMessageToClient(fd, "You must register first"));
	if (tokens[1][0] != '#')
		return (sendMessageToClient(fd, "Channel names must be start with #"));

	std::string channelName = tokens[1];
	std::string nickname = clients[fd]->getNickname();
	std::string username = clients[fd]->getUsername();

	std::map<std::string, Channel *>::iterator it;
	it = channels.find(channelName);
	if (it == channels.end())
	{
		channels[channelName] = new Channel(channelName);
		channels[channelName]->addUser(fd, nickname);
		clients[fd]->addChannel(channelName);
		channels[channelName]->setOperator(clients[fd]->getNickname());
		std::string str = ":" + nickname + "!" + username + " JOIN :" + channelName +" :" + nickname + "\r\n";
		send(clients[fd]->getFD(), str.c_str(),str.size(),0);
		sendMessageToClient(fd, "You have been appointed as a new operator");
		return;
	}
	if (channels[channelName]->addUser(fd, nickname) == false)
		return (sendMessageToClient(fd, "User is already in the channel"));
	clients[fd]->addChannel(channelName);
	std::string str = ":" + nickname + "!" + username + " JOIN :" + channelName +" :" + nickname + "\r\n";
	send(clients[fd]->getFD(), str.c_str(),str.size(),0);
}