#include "../Server.hpp"

void Server::nick(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() != 2)
		return (sendMessageToClient(fd, "You must pass 1 argument"));
	if (tokens[1][0] == '#')
		return (sendMessageToClient(fd, "Nicknames can't start with #"));
	if (tokens[1][0] == '@')
		return (sendMessageToClient(fd, "Nicknames can't start with @"));
	if (tokens[1].find("ADMIN") != std::string::npos)
		return (sendMessageToClient(fd, "Nicknames can't contains ADMIN"));

	std::string nickname = clients[fd]->getNickname();

	for (std::map<int, Client *>::iterator it = clients.begin(); it != clients.end(); it++)
		if (it->second->getNickname() == tokens[1])
			return (sendMessageToClient(fd, "This nickname is already in use"));
	std::string str = ":" + nickname + " NICK " + tokens[1];
	for(std::map<std::string,Channel *>::iterator it = channels.begin(); it != channels.end() ;it++)
	{
		if(it->second->checkUser(clients[fd]->getNickname()))
		{
			it->second->setUser(clients[fd]->getNickname(), tokens[1]);
		}
	}
	clients[fd]->setNickname(tokens[1]);
	sendsMessageToClient(fd, str);
	sendMessageToClient(fd, "Nickname has setted");
}