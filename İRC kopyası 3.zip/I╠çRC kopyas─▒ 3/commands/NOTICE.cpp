#include "../Server.hpp"

void Server::notice(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() < 3)
		return (sendMessageToClient(fd, "You must pass 2 argument at least"));
	if (clients[fd]->isRegistered() == false)
		return (sendMessageToClient(fd, "You must register first"));

	std::string targetChannel = tokens[1];
	if (targetChannel[0] == '#')
	{
		std::map<std::string, Channel *>::iterator it;
		it = channels.find(targetChannel);
		if (it == channels.end())
			return (sendMessageToClient(fd, "There is not a channel with that name"));
		if (clients[fd]->getNickname() != channels[tokens[1]]->getOperator())
			return (sendMessageToClient(fd, "You are not authorized to use this command"));	
		it->second->showMessage(clients[fd]->getNickname(), "[NOTICE] " + getMessage(tokens));
	}
	else
		return (sendMessageToClient(fd, "This command can only be used for channels"));
}