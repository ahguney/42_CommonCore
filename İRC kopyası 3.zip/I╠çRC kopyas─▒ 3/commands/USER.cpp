#include "../Server.hpp"

void Server::user(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() != 5)
		return (sendMessageToClient(fd, "You must pass 4 argument: USER <username> <unused> <unused> <realname>"));
	if (clients[fd]->getNickname().empty())
		return (sendMessageToClient(fd, "You must set a Nickname first"));
	if (clients[fd]->isEnteredPass() == false)
		return (sendMessageToClient(fd, "You must enter server password first"));

	clients[fd]->setUsername(tokens[1]);
	clients[fd]->setRealName(tokens[4]);
	clients[fd]->setDisplayName(clients[fd]->getNickname() + "!" + clients[fd]->getUsername() + "@" + clients[fd]->getHostname());
	clients[fd]->setRegistered();
	sendMessageToClient(fd, "Welcome " + clients[fd]->getDisplayName());
}