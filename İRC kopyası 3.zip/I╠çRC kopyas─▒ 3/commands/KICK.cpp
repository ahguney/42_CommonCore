#include "../Server.hpp"

void Server::kick(int fd, std::vector<std::string> tokens)
{
	if (tokens.size() < 3)
		return (sendMessageToClient(fd, "You must pass 3 arguments at least"));
	if (channels.find(tokens[1]) == channels.end())
		return (sendMessageToClient(fd, "There is not a channel with that name"));
	if (clients[fd]->getNickname() != channels[tokens[1]]->getOperator())
		return (sendMessageToClient(fd, "You are not authorized to kick"));	
	if (channels[tokens[1]]->checkUser(tokens[2]) == false)
		return (sendMessageToClient(fd, "There is not an user with that name in the channel"));	
	
	std::map<std::string, int> users = channels[tokens[1]]->getUsers();
	int targetFD = channels[tokens[1]]->getUsers().find(tokens[2])->second;
	part(targetFD, tokens);
	sendMessageToClient(targetFD, "You have been kicked from " + channels[tokens[1]]->getChannelName());
}