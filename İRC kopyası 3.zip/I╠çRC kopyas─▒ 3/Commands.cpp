#include "Server.hpp"

std::string getMessage(std::vector<std::string> tokens)
{
	std::string message;
	for (size_t i = 2; i < tokens.size(); i++)
	{
		message += tokens[i];
		if (!tokens[i + 1].empty())
			message += " ";
	}
	message += "\r\n";
	return message;
}

void Server::quit(int fd, std::vector<std::string> tokens)
{
	onClientDisconnect(fd, tokens);
}
