#ifndef PRESIDENTIALPARDONFORM_H
#define PRESIDENTIALPARDONFORM_H

#include <iostream>
#include "AForm.hpp"

class PresidentialPardonForm: public AForm {
	
public:

		PresidentialPardonForm();
        PresidentialPardonForm(const PresidentialPardonForm&);
		PresidentialPardonForm(const std::string target);
        virtual ~PresidentialPardonForm();
        PresidentialPardonForm &operator=(const PresidentialPardonForm& src);

		virtual void execute(Bureaucrat const & user) const;
};

#endif
