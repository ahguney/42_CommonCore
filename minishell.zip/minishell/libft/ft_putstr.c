#include "../includes/minishell.h"

void	ft_putstr(char *str)
{
	int	i;

	if (!str)
		return ;
	i = -1;
	while (str[++i] != '\0')
		ft_putchar(str[i]);
}
