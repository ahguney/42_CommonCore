#include "../includes/minishell.h"

char	*ft_substr(char const *src, unsigned int start, size_t len)
{
	size_t			i;
	size_t			slen;
	char			*tmp;

	if (!src)
		return (NULL);
	slen = ft_strlen(src);
	if (start > slen)
		return (NULL);
	tmp = malloc((len + 1) * sizeof(char));
	if (!tmp)
		return (NULL);
	i = 0;
	while (i < len)
	{
		tmp[i] = src[start + i];
		i++;
	}
	tmp[i] = '\0';
	return (tmp);
}
