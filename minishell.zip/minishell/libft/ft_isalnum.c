#include "../includes/minishell.h"

int	ft_isalnum(int nbr)
{
	if ((nbr >= 'a' && nbr <= 'z') || (nbr >= 'A' && nbr <= 'Z')
		|| (nbr >= '0' && nbr <= '9'))
		return (1);
	return (0);
}
