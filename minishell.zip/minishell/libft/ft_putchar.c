#include "../includes/minishell.h"

void	ft_putchar(char src)
{
	write(1, &src, 1);
}
