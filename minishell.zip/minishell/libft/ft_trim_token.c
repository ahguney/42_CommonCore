#include "../includes/minishell.h"

char	*ft_trim_token(char *token, char sep)
{
	int		i;

	if (!token)
		return (token);
	i = ft_strlen(token) - 1;
	while (token[i] == sep)
	{
		token[i] = '\0';
		i--;
	}
	while (*token == sep)
		token++;
	return (token);
}
