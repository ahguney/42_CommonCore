#include "../includes/minishell.h"

int	ft_close_fd(int fd)
{
	if (fd > 2)
	{
		close(fd);
		return (-1);
	}
	return (fd);
}
