#include "../includes/minishell.h"

void	*ft_calloc(size_t nbr, size_t size)

{
	void	*tab;

	tab = malloc(size * nbr);
	if (!tab)
		return (NULL);
	ft_bzero(tab, size * nbr);
	return (tab);
}
