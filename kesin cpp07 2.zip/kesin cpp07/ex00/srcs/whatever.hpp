/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   whatever.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ahguney <ahguney@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/07 18:25:07 by ahguney           #+#    #+#             */
/*   Updated: 2023/09/07 18:25:07 by ahguney          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#ifndef WHATEVER_HPP
# define WHATEVER_HPP

# include <iostream>

template <typename T> void	swap(T &src1, T &src2){
	T temp = src1;
	src1 = src2;
	src2 = temp;
}

template <typename T> T min(T const& first, T const& second){ 
	return (first < second ? first : second); 
}

template <typename T> T max(T const& first, T const& second) { 
	return (first > second ? first : second);
}

#endif